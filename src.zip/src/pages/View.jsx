import TodoView from "../components/TodoView";

const View = () => {
  return (
    <div className="area">
      <TodoView />
    </div>
  );
};

export default View;
