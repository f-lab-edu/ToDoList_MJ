import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./TodoItem.css";

const TodoView = ({ id, content, onEdit }) => {
  const nav = useNavigate();
  const [isEdit, setIsEdit] = useState(false);
  const [localContent, setLocalContent] = useState(content);

  const handleCancel = () => {
    nav("/");
  };
  const handleSave = () => {
    onEdit(id, localContent);
    setIsEdit(false);
  };
  const onEditContent = (e) => {
    setLocalContent(e.target.value);
  };
  const onKeydown = (e) => {
    if (e.keyCode === 13) {
      handleSave();
    }
  };
  return (
    <div className="todo-item">
      <input className="edit-input" type="text" value={localContent} onChange={onEditContent} onKeyDown={onKeydown} />
      <button className="todo-btn" onClick={handleSave}>
        완료
      </button>
      <button className="todo-btn" onClick={handleCancel}>
        취소
      </button>
    </div>
  );
};

export default TodoView;
